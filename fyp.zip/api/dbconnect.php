<?PHP
	$host = "localhost";
	$user = "root";
	$password = "";
	$database = "helpdesk";
	
	$conn = new mysqli($host,$user,$password,$database);
?>