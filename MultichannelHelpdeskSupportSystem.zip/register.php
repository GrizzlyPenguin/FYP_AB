<?php
    include('server.php'); 
?>
    
<!DOCTYPE html>
<html lang='en' data-ng-app='HelpdeskApp'>
    
<head>
    <title>Register</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" 
    integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <link type="text/css" href="css/helpdesk.css" rel="stylesheet" />
</head>

<body>
    <div data-ng-include="'templates/nav.html'"></div>



    <div class="background">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card card-signin my-5">
                        <div class="card-body">
                            <h2 class="text-center">Register</h2>

                            <form method="post" action="register.php" name="myForm" id="myForm" ng-app="">
                                <div class="form-group">
                                    <label class="m-0" for="name">*Name</label>
                                    <input class="form-control w-100 p-10" id="name" ng-model="Name" type="text" placeholder="Enter Username" name="Name" required>
                                    <span data-ng-show="myForm.Name.$touched">
                                    <span data-ng-show="myForm.Name.$error.required">**Your name is required</span>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label class="m-0" for="company">Company</label>
                                    <input class="form-control w-100 p-10" id="company" type="text" placeholder="Enter Company Name" name="Address">
                                </div>
                                <div class="form-group">
                                    <label class="m-0" for="contact">*Contact Number</label>
                                    <input class="form-control w-100 p-10" data-ng-pattern='/^[0-9]{10}$/' ng-model="ContactNumber" id="contact" type="text" placeholder="0123456789" name="ContactNumber" required>
                                    <span data-ng-show="myForm.ContactNumber.$touched">
                                    <span data-ng-show="myForm.ContactNumber.$error.required">**Contact Number is required</span>
                                    <span data-ng-show="myForm.ContactNumber.$invalid">**Must start with numberic numbers and 10 digits</span>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label class="m-0" for="contact">*Username</label>
                                    <input class="form-control w-100 p-10" id="username" type="text" placeholder="Enter Username" name="username" ng-model="username" required>
                                    <span data-ng-show="myForm.username.$touched">
                                    <span data-ng-show="myForm.username.$error.required">**Username is required</span>
                                    </span>
                                </div>
                                
                                <div class="form-group">
                                    <label class="m-0" for="password">*Password</label>
                                    <input class="form-control w-100 p-10" data-ng-minlength="8" id="password" type="password" placeholder="Password" name="Password_1" ng-model="Password_1" required>
                                    <span data-ng-show="myForm.Password_1.$touched">
                                    <span data-ng-show="myForm.Password_1.$error.required">**Password is required</span>
                                    <span data-ng-show="myForm.Password_1.$error.minlength">*Minimum 8 characters</span>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label class="m-0" for="password">Re-type Password</label>
                                    <input class="form-control w-100 p-10" id="password1" type="password" placeholder="Confirm Password" name="Password_2" ng-model="Password_2" required>
                                    <span data-ng-show="myForm.Password_2.$touched">
                                    <span data-ng-show="myForm.Password_2.$error.required">**Password is required</span>
                                    <span data-ng-show="Password_1!==Password_2">**Password mismatch</span>
                                    </span>
                                </div>
                                <input class="sr-only" name="role" value=""></span>
                                <div class="form-group">
                                    <label class="m-0" for="mail">*Email</label>
                                    <input class="form-control w-100 p-10" id="mail" type="email" placeholder="example@email.com" ng-model="Email" name="Email" required>
                                    <span data-ng-show="myForm.Email.$touched">
                                    <span data-ng-show="myForm.Email.$error.required">**Email is required</span><br/>
                                    <span data-ng-show="myForm.Email.$invalid">**Invalid email address</span>
                                    </span>
                                </div>
                               <!-- <label>
                                    <input type="checkbox" checked="checked" name="remember"> Remember me
                                </label>-->
                                <div class="col-md-12 text-center">
                                    <button class="btn btn-primary" data-ng-disabled="myForm.$invalid" type="submit" name="reg_user">Register</button>
                                    <p>
                                        Already a member? <a href="login.php">Sign in</a>
                                    </p>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--    <footer data-ng-include="'templates/footer.html'"></footer>-->

    <!--angular.min.js-->
    <script src="angularjs/angular.min.js"></script>
    <script src="angularjs/angular-ui-router.min.js"></script>
    <script src="angularjs/helpdesk.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
