<?php 
 session_start(); 
include('server.php');

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location: login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
        unset($_SESSION['CustID']);
		header("location: login.php");
	}
	
?>
<!DOCTYPE html>
<html lang='en' data-ng-app='HelpdeskApp'>

<head>
    <title>Employee Register Page</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">




    <link type="text/css" href="css/helpdesk.css" rel="stylesheet" />
</head>

<body>
    <!--    <div data-ng-include="'templates/nav.html'"></div>

    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">

            <a class="navbar-brand filter" href="index.php"><img src="img/logo.png" alt="Brand">
                QMHDS
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="index.php">
                            Home
                        </a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link" href="Dashboard.php#Pending">
                            Dashboard
                        </a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="knowledgebase.html">Knowledge Base</a>
                    </li>

                    <li class="nav-item" data-ng-controller="postCtrl">
                        <span class="sr-only" data-ng-init="roleInit('<?php echo $_SESSION['Role']; ?>')"></span>
                        <a class="nav-link" data-ng-show="role=='admin'" href="reg_employee.php">User Management</a>
                    </li>

                    <li class="nav-item" data-ng-controller="postCtrl">
                        <span class="sr-only" data-ng-init="roleInit('<?php echo $_SESSION['Role']; ?>')"></span>
                        <a class="nav-link" data-ng-show="role=='admin'" href="report.php">Report</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="account_edit.php"><?php echo ucfirst($_SESSION['username']); ?></a>
                    </li>

                    <li>
                        <button class="btn btn-danger btn-xs" title="Log Out" onclick=location.href="index.php?logout='1'">LOG OUT</button>
                    </li>
                </ul>
            </div>
        </div>
    </nav> -->
    
        <div data-ng-include="'templates/nav.php'"></div>

    <div class="background">
        <div class="jumbotron jumbotron-fluid">
            <div class="container">
                <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                    <div class="card card-signin my-5">
                        <div class="card-body">
                            <h2 class="text-center">Register Employee</h2>
                            <form method="post" action="reg_employee.php" name="myForm">
                                
                                <?php include('errors.php') ?>
              <div class="form-group">
                                    <label class="m-0" for="rname">*Name</label>
                                    <input class="form-control w-100 p-10" id="name" type="text" placeholder="Enter Your Name" name="name" ng-model="name" required>
                                    <span data-ng-show="myForm.name.$touched">
                                    <span data-ng-show="myForm.name.$error.required">**Staff's name is required</span>
                                    </span>
                                </div>
                                  
                                  <div class="form-group">
                                    <label class="m-0" for="contact">*Contact Number</label>
                                    <input class="form-control w-100 p-10" data-ng-pattern='/^[0-9]{10}$/' ng-model="contact" id="contact" type="text" placeholder="012-3456789" name="contact" required>
                                    <span data-ng-show="myForm.contact.$touched">
                                    <span data-ng-show="myForm.contact.$error.required">**Contact Number is required</span>
                                    <span data-ng-show="myForm.contact.$invalid">**Must start with numberic numbers and 10 digits</span>
                                    </span>
                                </div>
                                  
                                  <div class="form-group">
                                    <label class="m-0" for="Address">Address</label>
                                    <input class="form-control w-100 p-10" id="address" type="text" placeholder="Enter Your Address" name="address">
                                </div>
                                  
                                  <div class="form-group">
                                    <label class="m-0" for="email">Email</label>
                                    <input class="form-control w-100 p-10" id="mail" type="email" ng-model="email" placeholder="abc@gmail.com" name="email" required>
                                    <span data-ng-show="myForm.email.$touched">
                                    <span data-ng-show="myForm.email.$error.required">**Email is required</span><br/>
                                    <span data-ng-show="myForm.email.$invalid">**Invalid email address</span>
                                    </span>
                                </div>
                                   
                                   <div class="form-group">
                                    <label class="m-0" for="name">Username</label>
                                    <input class="form-control w-100 p-10" id="username" type="text" placeholder="Login Username" name="username" ng-model="username" required>
                                    <span data-ng-show="myForm.username.$touched">
                                    <span data-ng-show="myForm.username.$error.required">**Username is required</span>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label class="m-0" for="password1">Password</label>
                                    <input class="form-control w-100 p-10" data-ng-minlength="8" ng-model="Password_1" id="password" type="password" placeholder="Login Password" name="Password_1" required>
                                    <span data-ng-show="myForm.Password_1.$touched">
                                    <span data-ng-show="myForm.Password_1.$error.required">**Password is required</span>
                                    <span data-ng-show="myForm.Password_1.$error.minlength">*Minimum 8 characters</span>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label class="m-0" for="password2">Re-type Password</label>
                                    <input class="form-control w-100 p-10" id="password" ng-model="Password_2" type="password" placeholder="Confirm Login Password" name="Password_2" required>
                                    <span data-ng-show="myForm.Password_2.$touched">
                                    <span data-ng-show="myForm.Password_2.$error.required">**Password is required</span>
                                    <span data-ng-show="Password_1!==Password_2">**Password mismatch</span>
                                    </span>
                                </div>
                                <div class="form-group">
                                    <label for="pos">Job Position</label><br/>
                                    <input type="radio" name="position" value="Technician">Technician
                                    <span style="margin-right: 25px"></span>
                                    <input type="radio" name="position" value="Account Manager">Account Manager
                                </div>
                                <div class="col-md-12 text-center">
                                    <button class="btn btn-primary" type="submit" name="reg_emp" data-ng-disabled="myForm.$invalid">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!--    <div class="fixed-bottom" style="margin-bottom: 0" data-ng-include="'templates/footer.html'"></div>-->

    <!--angular.min.js-->
    <script src="angularjs/angular.min.js"></script>
    <script src="angularjs/angular-route.min.js"></script>
    <script src="angularjs/helpdesk.js"></script>

    <!-- jQuery – required for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--popper.js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />

    <script src="https://code.highcharts.com/modules/series-label.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>

    <!--bootstrap js-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
