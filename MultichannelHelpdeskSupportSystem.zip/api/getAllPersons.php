<?php
    include('dbconnect.php');
	$result = $conn->query("SELECT * FROM TICKET;");
	
    $outp = "";
	while($rs = $result->fetch_assoc()) {
		if ($outp != "") {
            $outp .= ",";
        }
        
        $outp .= '{"ticketNo":"'  . $rs["TicketNo"] . '",';
 		$outp .= '"title":"'  . $rs["TicketTitle"] . '",';
        $outp .= '"desc":"'  . $rs["TicketDesc"] . '",'; 
        $outp .= '"pid":"'  . $rs["PID"] . '",'; 
        $outp .= '"domain":"'  . $rs["DomainName"] . '",'; 
        $outp .= '"date":"'  . $rs["DateReceived"] . '",';
        $outp .= '"status":"' . $rs["Status"] . '",'; 
        $outp .= '"warranty":"' . $rs["Warranty"] . '",';
        $outp .= '"StaffID":"' . $rs["StaffID"] . '",';
        $outp .= '"sdate":"' . $rs["AcceptedDate"] . '",'; 
        $outp .= '"edate":"' . $rs["SolvedDate"] . '",'; 
        $outp .= '"budget":"' . $rs["BudgetTime"] . '",'; 
        $outp .= '"addDesc":"'  . $rs["AdditionalTicketDesc"] . '",';
        $outp .= '"online":"' . $rs["SourceOnline"] . '",'; 
        $outp .= '"offline":"' . $rs["SourceOffline"] . '",'; 
        $outp .= '"jobType":"'  . $rs["JobType"] . '"';

        $result2 = $conn->query("SELECT Name, Email, ContactNumber FROM CUSTOMER WHERE CustID = '".$rs["PID"]."';");
        $result3 = $conn->query("SELECT EmpName FROM EMPLOYEE WHERE EmpID = '".$rs["StaffID"]."';");
        $result4 = $conn->query("SELECT EmpName FROM EMPLOYEE WHERE EmpID = '".$rs["TransferredBy"]."';");
        
        if ($result2 !== FALSE){
            while ($rs = $result2->fetch_assoc()) {
                $outp .= "," . '"email":"' . $rs["Email"] . '"';
                $outp .= "," . '"contactNo":"' . $rs["ContactNumber"] . '"';
                $outp .= "," . '"Name":"' . $rs["Name"] . '"';
            }
        }
        
        if($result3 !== FALSE){
            while ($rs = $result3->fetch_assoc()) {
                $outp .= "," . '"EmpName":"' . $rs["EmpName"] . '"';
            }
        }
        
        if($result4 !== FALSE){
            while ($rs = $result4->fetch_assoc()) {
                $outp .= "," . '"transferredBy":"' . ucfirst($rs["EmpName"]) . '"';
            }
        }
        
        if ($outp != "") {
            $outp .= "}";
        }
    }

	$outp ='['.$outp.']';

	$conn->close();

	echo $outp;
?>
