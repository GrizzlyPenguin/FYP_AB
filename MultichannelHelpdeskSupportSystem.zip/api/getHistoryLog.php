<?php
    include('dbconnect.php');
    parse_str(file_get_contents("php://input"),$put_vars);

    $sql = 'error';
	$outp = "";

    if(isset($put_vars['tNo'])){
        $ticketNo = $put_vars['tNo'];

        $result = $conn->query("SELECT * FROM HISTORYLOG WHERE TicketNo = '". $ticketNo . "';");        
        
        if ($result !== FALSE){
            while ($rs = $result->fetch_assoc()) {
                if ($outp != "") {
                    $outp .= ",";
                }
                
                $outp .= '{"date":"' . date('d-M-Y', strtotime($rs["Date"])) . '",';
                $outp .= '"diagnosis":"' . $rs["Diagnosis"] . '",';
                $outp .= '"findings":"' . $rs["Findings"] . '",'; 
                $outp .= '"conclusion":"' . $rs["Conclusion"] . '",'; 
                $outp .= '"cause":"'  . $rs["Cause"] . '",'; 
                $outp .= '"timeSpent":"'  . $rs["TimeSpent"] . '",'; 

                $sql2 = "SELECT EmpName FROM EMPLOYEE WHERE EmpID = '".$rs["AttendedBy"]."';";
                
                if (($result2 = $conn->query($sql2)) !== FALSE) {
                    while ($rs2 = $result2->fetch_assoc()) {
                        $outp .= '"attendedBy":"' . $rs2["EmpName"]  . '"}';
                    }
                } else {
                    echo "Error: " . $sql2 ."<br/>". $rs["AttendedBy"]. $conn->error;
                }
            }
            
            $outp ='['.$outp.']';
            echo $outp;

            }else{
                echo "Error: " . $result . "<br>" . $conn->error;
            }
    }else{
         echo "Error: " . $sql . "<br>";
    }
    $conn->close();
?>
