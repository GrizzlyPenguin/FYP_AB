<?php
    include('dbconnect.php');
    $sql = '';
    
    //This line translating all params from js file to a variable named $put_vars
    parse_str(file_get_contents("php://input"),$put_vars);
        
        
    
                    
    
    
    if(isset($put_vars['title'])){
        // echo "putFormData";
        // $title = $put_vars['title'];
        // $desc = $put_vars['desc'];
        // $TicketNo = $put_vars['TicketNo'];
        // $status = $put_vars['status'];

        // $sql = "UPDATE TICKET SET TicketTitle = '". $title . "', TicketDesc = '". $desc . "', Status = '". $status . "' WHERE TicketNo = '". $TicketNo . "';";
    }else{
        echo "Accept Task";
        $TicketNo = $put_vars['TicketNo'];
        $EmpID = $put_vars['EmpID'];
        $UserID = "";
        $TicketTitle = "";
        $TicketDesc = "";
        $Name = "";
        $Email = "";
        $empName = "";
        
        $sql = "UPDATE TICKET SET Status ='Pending', StaffID = '". $EmpID . "', DateReceived = DateReceived, AcceptedDate = CURRENT_TIMESTAMP WHERE TicketNo = '". $TicketNo . "';";
        
        //Respond Message
        if ($conn->query($sql) === TRUE) {
            echo ("Updated Sucessfully!");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
        
        $sql2 = "SELECT PID, TicketDesc, TicketTitle FROM TICKET WHERE TicketNo = '".$TicketNo."';";
        
        if (($result = $conn->query($sql2)) !== FALSE)
        {
            while($row = $result->fetch_assoc())
            {
                $UserID = $row["PID"];
                
                $TicketTitle = $row["TicketTitle"];
                
                $TicketDesc = $row["TicketDesc"];
                
                break;
            }
            
        }else{
            echo "Error: " . $sql2 . "<br>" . $conn->error;
        }
        
        $sql3 = "Select Email, Name FROM CUSTOMER WHERE CustID = '". $UserID . "';";
            
        if (($result = $conn->query($sql3)) !== FALSE)
        {
            while($row = $result->fetch_assoc())
            {
                $Name = $row["Name"];
                $Email = $row["Email"];
                break;
            }
        }else{
            echo "Error: " . $sql3 . "<br>" . $conn->error;
        }
            
        $sql4 = "SELECT Name FROM EMPLOYEE WHERE EmpID = '".$EmpID."';";
                
        if (($result = $conn->query($sql4)) !== FALSE)
        {
            while($row = $result->fetch_assoc())
            {
                $empName = $row["Name"];
                echo "Employee Name: ". $empName;
                break;
            }
            
            $to      =  $Email;
    
            $subject = 'Ticket Accepted'; 
            
            $message = '<p>Dear '.ucwords($Name).',</p>
            <p>Your ticket has been handling by our techinician now. Our techinician will contact you in a short while.<br/>
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="btn btn-primary">
              <tbody>
                <tr>
                  <td align="left">
                    <tr><td>Ticket ID: <b>'.$TicketNo.'</b><br/></td></tr>
                    <tr><td>Product Name: <b>'.$TicketTitle.'</b><br/></td></tr>
                    <tr><td>Description: <b>'.$TicketDesc.'</b></td></tr>
                    <hr style="border-top: 1px solid;">
                    <tr><td>Attending By: <b>'.$empName.'</b><br/><br/></td></tr>
                    <tr><td></td></tr>
                    <tr>
                        <td>Best regards,</td>
                    </tr>
                    <tr>
                        <td>Helpdesk Support Team</td>
                    </tr>
                  </td>
                </tr>
              </tbody>
            </table>';
            include '../mail.php';
        }else
            echo "Error: ".$sql4."<br>" . $conn->error;
    }

    
	$conn->close();
?>