<?php
    include('dbconnect.php');
    parse_str(file_get_contents("php://input"),$put_vars);

    $sql = 'error';
	$outp = "";

    if(isset($put_vars['tNo'])){
        $ticketNo = $put_vars['tNo'];

        $sql = "SELECT EmpName FROM EMPLOYEE WHERE EmpID = '".$rs["AttendedBy"]."';";
        
        if (($result = $conn->query($sql)) !== FALSE) {
            while ($rs = $result->fetch_assoc()) {
                $outp = $rs["EmpName"];
            }
            echo $outp;
        } else {
            echo "Error: " . $sql ."<br/>". $rs["AttendedBy"]. $conn->error;
        }
    }else{
         echo "Error: " . $sql . "<br>";
    }
    $conn->close();
?>
