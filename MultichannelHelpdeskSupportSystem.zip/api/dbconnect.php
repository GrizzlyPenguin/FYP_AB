<?PHP
	$host = "localhost";
	$user = "smdigita_support";
	$password = "Hd=1@pn@{2$5";
	$database = "smdigita_helpdesk";
	
	$conn = new mysqli($host,$user,$password,$database);
?>