<?php
    include('dbconnect.php');
    if(isset($_POST['budget']) || isset($_POST['spent']) || isset($_POST['Diagnosis']) || isset($_POST['findings']) || isset($_POST['conclusion']) || isset($_POST['cause']) || isset($_POST['pid']) || isset($_POST['ticketID']) || isset($_POST['ticketStat']) || isset($_POST['addDesc']) || isset($_POST['online']) || isset($_POST['offline']) || !empty($_POST['jobType']))
    {
        $budget = $_POST['budget'];
        $spent = $_POST['spent'];
        $addDesc = $_POST['addDesc'];
        $online = $_POST['online'];
        $offline = $_POST['offline'];
        $jobType = $_POST['jobType'];
        $Diagnosis = $_POST['Diagnosis'];
        $findings = $_POST['findings'];
        $conclusion = $_POST['conclusion'];
        $cause = $_POST['cause'];
        $pid = $_POST['pid'];
        $ticketID = $_POST['ticketID'];        
        $ticketStat = $_POST['ticketStat'];
        $transfer = $_POST['transfer'];

        if (!empty($Diagnosis) || !empty($findings) || !empty($conclusion) || !empty($cause))   {
            $Diagnosis = str_replace("\n", "\\\\n", $Diagnosis);
            $findings = str_replace("\n", "\\\\n", $findings);
            $cause = str_replace("\n", "\\\\n", $cause);
            $conclusion = str_replace("\n", "\\\\n", $conclusion);
            
            $sql = "INSERT INTO HISTORYLOG(Diagnosis, findings, Conclusion, cause, EmpID, ticketNo, AttendedBy, TimeSpent) VALUES
            ('". $Diagnosis ."','" . $findings . "','".$conclusion."','".$cause."','".$pid."','".$ticketID."','".$pid."','".$spent."')";
            if ($conn->query($sql) === TRUE) {
                echo "New log created successfully";                
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;  
            }
//        ON DUPLICATE KEY UPDATE Diagnosis = '".$Diagnosis."', findings = '".$findings."', conclusion = '".$conclusion."', cause = '".$cause."', attendedBy = '".$pid."';";
        }
        
        if (!empty($_POST['addDesc'])){
            $sql4 = "UPDATE TICKET SET AdditionalTicketDesc = '". $addDesc . "'WHERE ticketNo = '".$ticketID."';";
             if ($conn->query($sql4) === TRUE) {
                echo "Addtional tikcet description updated successfully";
            } else {
                echo "Error: " . $sql4 . "<br>" . $conn->error;
            }
        }
        
        if ($budget !== '0'){
            $sql4 = "UPDATE TICKET SET BudgetTime = '". $budget . "'WHERE ticketNo = '".$ticketID."';";
             if ($conn->query($sql4) === TRUE) {
                echo "budget time set successfully";
            } else {
                echo "Error: " . $sql4 . "<br>" . $conn->error;
            }
        }
        
        if (!empty($_POST['online']) || !empty($_POST['offline']) || !empty($_POST['jobType'])){
             $online = str_replace('\\', '\\\\\\\\', $online);
             $offline = str_replace('\\', '\\\\\\\\', $offline);
            
            $sql5 = "UPDATE TICKET SET SourceOnline = '". $online . "', SourceOffline = '".$offline."', JobType = '".$jobType."'WHERE ticketNo = '".$ticketID."';";
             if ($conn->query($sql5) === TRUE) {
                echo "Addtional tikcet description updated successfully";
            } else {
                echo "Error: " . $sql5 . "<br>" . $conn->error;
            }
        }
        
        if (empty($_POST['transfer'])){
            $sql2 = "UPDATE TICKET SET Status = '". $ticketStat . "'WHERE ticketNo = '".$ticketID."';";
            if ($conn->query($sql2) === TRUE) {
                echo "Status updated successfully";
            } else {
                echo "Error: " . $sql2 . "<br>" . $conn->error;
            }
        }else{
            $sql3 = "UPDATE TICKET SET Status = '". $ticketStat . "', StaffID = '". $transfer. "', TransferredBy = '". $pid . "' WHERE ticketNo = '".$ticketID."';";
                if ($conn->query($sql3) === TRUE) {
                echo "Status updated and transfer to new staff successfully";
            } else {
                echo "Error: " . $sql3 . "<br>" . $conn->error;
            }
        }
        
        $UserID = "";
        $TicketTitle = "";
        $TicketDesc = "";
        $Name = "";
        $Email = "";
        $empName = "";
        
        $sql8 = "SELECT PID, TicketDesc, TicketTitle FROM TICKET WHERE TicketNo = '".$ticketID."';";
        
        if (($result = $conn->query($sql8)) !== FALSE)
        {
            while($row = $result->fetch_assoc())
            {
                $UserID = $row["PID"];
                
                $TicketTitle = $row["TicketTitle"];
                
                $TicketDesc = $row["TicketDesc"];
                
                break;
            }
        }else{
            echo "Error: " . $sql8 . "<br>" . $conn->error;
        }
        
        $sql7 = "Select Email, Name FROM CUSTOMER WHERE CustID = '". $UserID . "';";
            
        if (($result = $conn->query($sql7)) !== FALSE)
        {
            while($row = $result->fetch_assoc())
            {
                $Name = $row["Name"];
                $Email = $row["Email"];
                break;
            }
            
        }else{
            echo "Error: " . $sql7 . "<br>" . $conn->error;
        }
        
        if ($ticketStat=="Solved"){
            $sql6 = "UPDATE TICKET SET DateReceived = DateReceived, AcceptedDate = AcceptedDate, SolvedDate = CURRENT_TIMESTAMP WHERE TicketNo = '". $ticketID . "';"; 
            if ($conn->query($sql6) === TRUE) {
                
                $sql9 = "SELECT Name FROM EMPLOYEE WHERE EmpID = '".$pid."';";
                
                if (($result = $conn->query($sql9)) !== FALSE)
                {
                    while($row = $result->fetch_assoc())
                    {
                        $empName = $row["Name"];
                        break;
                    }
                }else
                    echo "Error: " . $sql9 . "<br>" . $conn->error;
                    
                $to      =  $Email;
    
                $subject = 'Ticket Solved'; 
                
                
                $message = '<p>Dear '.ucwords($Name).',</p>
                <p>Your ticket has been solved by our techinician.<br/>
                <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                  <tbody>
                    <tr>
                      <td align="left">
                        <tr><td>Ticket ID: <b>'.$ticketID.'</b><br/></td></tr>
                        <tr><td>Product Name: <b>'.$TicketTitle.'</b><br/></td></tr>
                        <tr><td>Description: <b>'.$TicketDesc.'</b></td></tr>
                        <hr style="border-top: 1px solid;">
                        <tr><td>History Log: </b></td></tr>
                        <table role="presentation" border="1" cellpadding="0" cellspacing="0">
                        <thead>
                             <tr>
                                <th>Date</th>
                                <th>Diagnosis</th>
                                <th>Findings</th>
                                <th>Cause</th>
                                <th>Conclusion</th>
                                <th>Spent</th>
                                
                             </tr>
                        </thead>
                        <tbody>';
                            
                            
                        $result = $conn->query("SELECT * FROM HISTORYLOG WHERE TicketNo = '". $ticketID . "';");        
                        $totalTime = 0;
                        
                        if ($result !== FALSE){
                            while ($row = $result->fetch_assoc()) {
                                
                                $message .= '<tr><td>'.date('d-M-Y', strtotime($row["Date"])).'</td>';
                                $message .= '<td>'.$row["Diagnosis"].'</td>';
                                $message .= '<td>'.$row["Findings"].'</td>';
                                $message .= '<td>'.$row["Cause"].'</td>';
                                $message .= '<td>'.$row["Conclusion"].'</td>';
                                $message .= '<td>'.$row["TimeSpent"].'</td></tr>';
                                $totalTime += $row["TimeSpent"];
                            }
                        }
                            
                        $message .= '<tr><td class="text-right" colspan="5">Total Time Spent</td>
                        <td>'.$totalTime.' hrs</td></tr>
                        </tbody>
                        </table>
                        
                        
                        For further enquiry please email to <u>felix@webnyou.com</u>.<br><br>
                        <tr><td></td></tr>
                        <tr>
                            <td>Best regards,</td>
                        </tr>
                        <tr>
                            <td>Helpdesk Support Team</td>
                        </tr>
                      </td>
                    </tr>
                  </tbody>
                </table>';
                include '../mail.php';
                
                
                echo "Solved date updated successfully";
            } else {
                echo "Error: " . $sql6 . "<br>" . $conn->error;
            }
        }
        
       
                
    }
	$conn->close();
?>