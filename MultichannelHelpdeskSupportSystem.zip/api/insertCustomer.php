<?php
    include('dbconnect.php');
    	$errors = array();
    if(isset($_POST['name']) || isset($_POST['contactNo']) || isset($_POST['email']))
    {
        $name = $_POST['name'];
        $contactNo = $_POST['contactNo'];
        $email = $_POST['email'];
        
        if (count($errors) == 0) {
            
            $sql = "INSERT INTO CUSTOMER(ContactNumber,Email, Name) VALUES ('". $contactNo ."','". $email ."','". $name ."')";
            
            if ($conn->query($sql) === TRUE) {
                echo "New customer created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
    }
	$conn->close();
?>

