<?php
include 'dbconnect.php';

ini_set('display_errors', 1);
    error_reporting(E_ALL);
    
    if(isset($_GET['id']) && isset($_GET['code'])){
    	
        $id=$_GET['id'];
        $code=$_GET['code'];
        
        $Name = "";
        $Address = "";
        $username = "";
        $Email = "";
        $Password_1 = "";
        $ContactNumber = "";
        
		$query = "SELECT Name, Address, username, Email, Password, ContactNumber FROM VERIFY WHERE CustID =".$id." AND Token='".$code."';";
		
    	if (($result = $conn->query($query)) !== FALSE){
    	    while($row = $result->fetch_assoc()) {
    	        $Name = $row["Name"];
    	        $Address = $row["Address"];
    	        $username = $row["username"];
    	        $Email = $row["Email"];
    	        $Password_1 = $row["Password"];
    	        $ContactNumber = $row["ContactNumber"];
    	    }
    	}else{
            echo "Error: " . $query . "<br>" . $conn->error;
        }
    	
    	//Register customer
		$query1 = "INSERT INTO CUSTOMER (Name, Address, username, Email, Password, ContactNumber, Logout) 
    					  VALUES('$Name', '$Address',  '$username', '$Email', '$Password_1', '$ContactNumber','');";
    					  
    					  
    	  if (($result = $conn->query($query1)) !== FALSE){
    	      
    	  }else
    	     echo "Error: " . $query1 . "<br>" . $conn->error;
    	
    	
    	$delete= "DELETE FROM VERIFY WHERE CustID='$id' and Token='$code';";

	    if (($result = $conn->query($delete)) !== FALSE){
	    }else
	        echo "Error: " . $delete . "<br>" . $conn->error;
    	    
        $to      = $Email; 

        $subject = 'Registration Success'; 
        
        // In case any of our lines are larger than 70 characters, we should use wordwrap()
        
        $message = '<p>Dear '.ucwords($Name).',</p>
                <p>Thanks for registering in Web & You helpdesk support</p>
                <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="btn btn-primary">
                  <tbody>
                    <tr>
                      <td align="left">
                        <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                          <tbody">
                            <tr>
                              <td> <a href="http://103.6.196.63/~smdigitalcom/Helpdesk/login.php" target="_blank">login & submit ticket now</a> </td>
                            </tr>
                          </tbody>
                        </table>
                        <tr><td></td></tr>
                        <tr>
                            <td>Best regards,</td>
                        </tr>
                        <tr>
                            <td>Helpdesk Support Team</td>
                        </tr>
                      </td>
                    </tr>
                  </tbody>
                </table>';
                                 
                include '../mail.php';
                
                echo 
                    "<script type=\"text/javascript\">".
                    "window.alert('Email Verified, you can login to your account now');".
                    "top.location = '../login.php';".
                    "</script>";
        exit;  
	}
?>