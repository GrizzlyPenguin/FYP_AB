<?php
    include('dbconnect.php');
    	$errors = array();
    if(isset($_POST['cid']) || isset($_POST['TicketTitle']) || isset($_POST['UserID']) || isset($_POST['TicketDesc']) || isset($_POST['warranty']) || isset($_POST['domain']))
    {
        $cid = $_POST['cid'];
        $TicketTitle = $_POST['TicketTitle'];
        $TicketDesc = $_POST['TicketDesc'];
        $UserID = $_POST['UserID'];
        $Status = $_POST['Status'];
        $warranty = $_POST['warranty'];
        $domain = $_POST['domain'];
        
        if (empty($TicketTitle)) { array_push($errors, "Ticket title is required");}
        echo "CUSTID: ".$cid;
        if (count($errors) == 0) {
            if (empty($UserID)){
                $UserID = $cid;
            }
            
            $sql2 = "INSERT INTO TICKET(TicketTitle, TicketDesc, DomainName, Warranty, PID, DateReceived,Status) VALUES
                ('". $TicketTitle ."','" . $TicketDesc . "','".$domain."','".$warranty."','".$UserID."' ,CURRENT_TIMESTAMP(),'Open') ;";
                
                if ($conn->query($sql2) === TRUE) {
                    echo "New ticket created successfully";
                    
                    $sql3 = "Select Email, Name FROM CUSTOMER WHERE CustID = '". $UserID . "';";
                    
                    if (($result = $conn->query($sql3)) !== FALSE)
                    {
                        $Name = "";
                        $Email = "";
                        while($row = $result->fetch_assoc())
                        {
                            $Name = $row["Name"];
                            $Email = $row["Email"];
                            break;
                        }
                        
                        $sql4 = "SELECT TicketNo FROM TICKET WHERE PID = '" . $UserID . "';";
                        if (($result = $conn->query($sql4)) !== FALSE)
                        {
                            while($row = $result->fetch_assoc()){
                                $ticketID = $row["TicketNo"];
                            }
                        }else{
                            echo "Error: " . $sql4 . "<br>" . $conn->error;
                        }
                        
                        $to      =  $Email;
        
                        $subject = 'Ticket Submitted Success'; 
                        
                        $message = '<p>Dear '.ucwords($Name).',</p><br/>
                        <p>Thank you for submitting a ticket! </p>
                        <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="btn btn-primary">
                          <tbody>
                            <tr>
                              <td align="left">
                                <tr><td>Ticket ID: <b>'.$ticketID.'</b><br/></td></tr>
                                <tr><td>Product Name: <b>'.$TicketTitle.'</b><br/></td></tr>
                                <tr><td>Description: <b>'.$TicketDesc.'</b><br/></td></tr>
                                <tr><td>Our techinician will get back to you soon.<br/></td></tr>
                                <tr><td></td></tr>
                                <tr>
                                    <td>Best regards,</td>
                                </tr>
                                <tr>
                                    <td>Helpdesk Support Team</td>
                                </tr>
                              </td>
                            </tr>
                          </tbody>
                        </table>';
                    
                        include '../mail.php';
                        
                    }else{
                        echo "Error: " . $sql3 . "<br>" . $conn->error;
                    }
                    
                    
                } else {
                    echo "Error: " . $sql2 . "<br>" . $conn->error;
                }
        }
    }
	$conn->close();
?>

