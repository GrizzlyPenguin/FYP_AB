<?php
    include "server.php";
   if (!isset($_SESSION['username'])) {
		header('location: login.php');
	}

    if (isset($_GET['logout'])) {
        $logintime = "UPDATE EMPLOYEE SET Logout = CURRENT_TIMESTAMP() where EmpName = '{$_SESSION['username']}'";
        $results3 = mysqli_query($db, $logintime);
        
        $logintime2 = "UPDATE CUSTOMER SET Logout = CURRENT_TIMESTAMP() where username = '{$_SESSION['username']}'";
        $results4 = mysqli_query($db, $logintime2);
        
        session_destroy();
		unset($_SESSION['username']);
        unset($_SESSION['CustID']);
        header("location: login.php");
	}
?>

<!DOCTYPE html>
<html lang='en' data-ng-app='HelpdeskApp'>

<head>
    <title>Personal Dashboard</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">

    <!-- icon -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css" integrity="sha384-oS3vJWv+0UjzBfQzYUhtDYW+Pj2yciDJxpsK1OYPAYjqT085Qq/1cq5FLXAZQ7Ay" crossorigin="anonymous">

    <link type="text/css" href="css/helpdesk.css" rel="stylesheet" />
</head>

<body>

    <div data-ng-include="'templates/nav.php'"></div>

    <div class="container top">
        <div class="row">
            <div class="col-md-3">
                <div data-ng-include="'templates/sidebar.php'"></div>
            </div>
            <!--table-->
            <div data-ng-view class="col-md-9 pl-md-0"></div>
        </div>
    </div>
    
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
        <div class="modal-dialog">
            <div class="modal-content" data-ng-controller="postCtrl">
            <span class="sr-only" data-ng-init="roleInit('<?php echo ucfirst($_SESSION['Role']); ?>')"></span>
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Ticket Form</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <form method="get" id="ticketForm">
                        <div data-ng-show="role">
                            <div class="form-group">
                                <label for="Cid">ID</label>
                                <input type="text" class="form-control w-100" data-ng-model="Cid" id="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="Product">Product</label>
                            <input type="text" class="form-control w-100" data-ng-model="TicketTitle" id="title">
                        </div>
                        <div class="form-group">
                            <label for="Textarea1">Description</label>
                            <textarea class="form-control" id="Textarea1" rows="3" data-ng-model="TicketDesc"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="warranty">Warranty</label> <br/>
                                <label>
                                <input type="radio" ng-model="warranty" value="yes">Yes
                                <span style="margin-right: 25px"></span>
                                <input type="radio" ng-model="warranty" value="no">No
                            </label><br/>
                        </div>
                        <div class="form-group">
                            <label for="domain">Domain name</label>
                            <input type="text" class="form-control w-100" data-ng-model="domain" id="domain">
                        </div>
                        <!--<div class="form-group">-->
                        <!--    <label for="FormControlFile1">Attachments</label>-->
                        <!--    <input type="file" class="form-control-file" id="FormControlFile1">-->
                        <!--</div>-->
                    </form>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <span class="sr-only" data-ng-init="userInit('<?php echo $_SESSION['CustID']; ?>')"></span>
                    <button type="submit" form="ticketForm" value="Submit" class="btn btn-primary" data-ng-click="postData(Cid, TicketTitle, TicketDesc, UserID, warranty, domain)" data-dismiss="modal">Submit</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="regModal">
        <div class="modal-dialog">
            <div class="modal-content" data-ng-controller="postCtrl">
            
                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Ticket Form</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <span class="sr-only" id="role" data-ng-init="roleInit('<?php echo ucfirst($_SESSION['Role']); ?>')">{{role}}</span>
                    <form method="post" action="Dashboard.php" name="myForm" id="myForm">
                        <?php include('errors.php') ?>
                        <div class="form-group">
                            <label class="m-0" for="name">*Name</label>
                            <input class="form-control w-100 p-10" id="name" ng-model="Name" type="text" placeholder="Enter Username" name="Name" required>
                            <span data-ng-show="myForm.Name.$touched">
                            <span data-ng-show="myForm.Name.$error.required">**Your name is required</span>
                            </span>
                        </div>
                        <div class="form-group">
                            <label class="m-0" for="company">Company</label>
                            <input class="form-control w-100 p-10" id="company" type="text" placeholder="Enter Company Name" name="Address">
                        </div>
                        <div class="form-group">
                            <label class="m-0" for="contact">*Contact Number</label>
                            <input class="form-control w-100 p-10" data-ng-pattern='/^[0-9]{10}$/' ng-model="ContactNumber" id="contact" type="text" placeholder="0123456789" name="ContactNumber" required>
                            <span data-ng-show="myForm.ContactNumber.$touched">
                            <span data-ng-show="myForm.ContactNumber.$error.required">**Contact Number is required</span>
                            <span data-ng-show="myForm.ContactNumber.$invalid">**Must start with numberic numbers and 10 digits</span>
                            </span>
                        </div>
                        <div class="form-group">
                            <label class="m-0" for="contact">*Username</label>
                            <input class="form-control w-100 p-10" id="username" type="text" placeholder="Enter Username" name="username" ng-model="username" required>
                            <span data-ng-show="myForm.username.$touched">
                            <span data-ng-show="myForm.username.$error.required">**Username is required</span>
                            </span>
                        </div>
                        
                        <div class="form-group">
                            <label class="m-0" for="password">*Password</label>
                            <input class="form-control w-100 p-10" data-ng-minlength="8" id="password" type="password" placeholder="Password" name="Password_1" ng-model="Password_1" required>
                            <span data-ng-show="myForm.Password_1.$touched">
                            <span data-ng-show="myForm.Password_1.$error.required">**Password is required</span>
                            <span data-ng-show="myForm.Password_1.$error.minlength">*Minimum 8 characters</span>
                            </span>
                        </div>
                        <div class="form-group">
                            <label class="m-0" for="password">Re-type Password</label>
                            <input class="form-control w-100 p-10" id="passwordConfirm" type="password" placeholder="Confirm Password" name="Password_2" ng-model="Password_2" required>
                            <span data-ng-show="myForm.Password_2.$touched">
                            <span data-ng-show="myForm.Password_2.$error.required">**Password is required</span>
                            <span data-ng-show="Password_1!==Password_2">**Password mismatch</span>
                            </span>
                        </div>
                        <input class="sr-only" name="role" value="role"></span>
                        <div class="form-group">
                            <label class="m-0" for="mail">*Email</label>
                            <input class="form-control w-100 p-10" id="mail" type="email" placeholder="example@email.com" ng-model="Email" name="Email" required>
                            <span data-ng-show="myForm.Email.$touched">
                            <span data-ng-show="myForm.Email.$error.required">**Email is required</span><br/>
                            <span data-ng-show="myForm.Email.$invalid">**Invalid email address</span>
                            </span>
                        </div>
                        <div class="col-md-12 text-center">
                            <button class="btn btn-primary" data-ng-disabled="myForm.$invalid" type="submit" name="reg_user">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <!--angular.min.js-->
    <script src="angularjs/angular.min.js"></script>
    
    <script src="angularjs/angular-route.min.js"></script>
    <script src="angularjs/helpdesk.js"></script>
    
    <!--timepicker-->
<!--
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular-animate.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.1/angular-sanitize.js"></script>
    <script src="angularjs/ui-bootstrap-custom-tpls-2.5.0.min.js"></script>
    <script src="angularjs/example.js"></script>
-->
   
    <!-- jQuery – required for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--popper.js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />  
   <!--<link href="css/bootstrap.min.css" rel="stylesheet" />-->
    <!--bootstrap js-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
