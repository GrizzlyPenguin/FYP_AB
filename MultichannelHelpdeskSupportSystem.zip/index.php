<?php 
	include('server.php'); 
	if (!isset($_SESSION['username'])) {
		header('location: login.php');
	}

    if (isset($_GET['logout'])) {
        $logintime = "UPDATE EMPLOYEE SET Logout = CURRENT_TIMESTAMP() where EmpName = '{$_SESSION['username']}'";
        $results3 = mysqli_query($db, $logintime);
        
        $logintime2 = "UPDATE CUSTOMER SET Logout = CURRENT_TIMESTAMP() where username = '{$_SESSION['username']}'";
        $results4 = mysqli_query($db, $logintime2);
        
        session_destroy();
		unset($_SESSION['username']);
        unset($_SESSION['CustID']);
        header("location: login.php");
	}
?>

<!DOCTYPE html>
<html lang="en" data-ng-app='HelpdeskApp'>

<head>
    <title>Welcome to Multichannel Helpdesk Support System</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="refresh" content="900;url=index.php?logout='1'" />
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">


    <link type="text/css" href="css/helpdesk.css" rel="stylesheet" />
</head>

<body>
    <div data-ng-include="'templates/nav.php'"></div>

    <div class="background">
        <div class="jumbotron jumbotron-fluid">
            <div class="container vertical-center" id="test">

                <h1 class="col-md-8 col-sm-8 col-xs-8 p-0">Welcome to Multichannel Helpdesk Support System,
                    <span class="upper">
                        <?php echo $_SESSION['username']; ?>
                    </span>
                </h1>

                <p>Your satisfaction is our desire</p>

                <div class="button-group">
                    <!--<div class="text-center">-->
                    <button type="button" class="btn" data-toggle="modal" data-target="#myModal">
                        Submit Ticket
                    </button>

                    <a class="btn" href="knowledgebase.php">FAQ</a>
                </div>
                
            </div>
        </div>
    </div>

    <div class="container">

        <!-- The Modal -->
        <div class="modal fade" id="myModal">
            <div class="modal-dialog">
                <div class="modal-content" data-ng-controller="postCtrl">
                <span class="sr-only" data-ng-init="roleInit('<?php echo ucfirst($_SESSION['Role']); ?>')"></span>
                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title">Technical Report</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <form method="get" id="ticketForm" name="myForm" >
                            <div data-ng-show="role">
                                <div class="form-group">
                                    <label for="Cid">ID</label>
                                    <input type="text" class="form-control w-100" data-ng-model="Cid" id="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="title">Product Name</label>
                                <input type="text" class="form-control w-100" data-ng-model="TicketTitle" id="title" required>
                            </div>
                            <div class="form-group">
                                <label for="Textarea1">Description</label>
                                <textarea class="form-control" id="Textarea1" rows="3" data-ng-model="TicketDesc" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="warranty">Warranty</label> <br/>
                                    <label>
                                    <input type="radio" ng-model="warranty" value="yes">Yes
                                    <span style="margin-right: 25px"></span>
                                    <input type="radio" ng-model="warranty" value="no">No
                                </label><br/>
                            </div>
                            <div class="form-group">
                                <label for="domain">Domain name</label>
                                <input type="text" class="form-control w-100" data-ng-model="domain" id="domain">
                                    <span data-ng-show="myForm.domain.$touched">
                                    <span>**Email is required</span><br/>
                                    <span>**Invalid email address</span>
                                    </span>
                            </div>
                        </form>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <span class="sr-only" data-ng-init="userInit('<?php echo $_SESSION['CustID']; ?>')"></span>
                        <button type="submit" form="ticketForm" value="Submit" class="btn btn-primary" data-ng-click="postData(Cid, TicketTitle, TicketDesc, UserID, warranty, domain)" data-dismiss="modal">Submit</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="fixed-bottom" style="margin-bottom: 0" data-ng-include="'templates/footer.html'"></div>

    <!--angular.min.js-->
    <script src="angularjs/angular.min.js"></script>
    <script src="angularjs/angular-route.min.js"></script>
    <script src="angularjs/helpdesk.js"></script>

    <!-- jQuery – required for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!--popper.js-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />

    <!--bootstrap js-->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>

</html>
