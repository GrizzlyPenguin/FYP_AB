<?php 
	session_start();
?>
<div data-ng-controller="putCtrl">
    <div class="table-tasks " data-ng-controller="getCtrl">
        <div data-ng-controller="postCtrl">
        <div ng-controller="sort" style="margin-top:50px; margin-left:20px">
            <div class="tableTitle">
                <div class="row">
                    <h3 data-ng-show="role">Personal - All Tasks</h3>
                    <h3 data-ng-hide="role">All Tickets</h3>

                    <div class="col p-0">
                        <button data-toggle="modal" data-target="#myModal" class="btn btn-primary float-right">+ Ticket</button>
                    </div>
                </div>
            </div>
            <div class="table-responsive">
                <table id="personal" class="table table-sm table-striped table-bordered table-hover">
                    <thead>
                        <tr class="text-center">
                            <th ng-click='sortColumn("ticketNo")' class="th-sm">#
                            </th>
                            <th ng-click='sortColumn("title")' class="th-sm">Product
                            </th>
                            <th ng-click='sortColumn("desc")' class="th-sm">Description
                            </th>
                            <th ng-click='sortColumn("pid")' class="th-sm">Customer
                            </th>
                            <th ng-click='sortColumn("date")' class="th-sm">Date Created
                            </th>
                            <th ng-click='sortColumn("status")' class="th-sm">Status
                            </th>
                        </tr>
                    </thead>
                    <div>
                        <span class="sr-only" data-ng-init="empInit('<?php echo $_SESSION['EmpID']; ?>')"></span>
                        <span class="sr-only" data-ng-init="custInit('<?php echo $_SESSION['CustID']; ?>')"></span>
                        <span class="sr-only" data-ng-init="tktLeng('All', EmpID, CustID)"></span>
                        <tbody>
                            <tr class="text-center" data-ng-repeat="ticket in tickets |orderBy:column:reverse|filter:searchText| filter:{StaffID:EmpID, pid:CustID}| offset: currentPage*ticketsPerPage | limitTo: ticketsPerPage"
                            data-toggle="modal" data-target="#viewModal" data-ng-click="init(ticket); searchName(ticket.pid); getLog(ticket.ticketNo)">
                                <td>{{ticket.ticketNo}}</td>
                                <td>{{ticket.title}}</td>
                                <td class="trunket">{{ticket.desc}}</td>
                                <td class="text-capitalize">{{ticket.Name}}</td>
                                <td>{{ticket.date}}</td>
                                <td class="{{ticket.status}}"><b>{{ticket.status}}</b></td>
                            </tr>
                        </tbody>
                        <tfoot data-ng-show="tickets.length>9">
                            <tr>
            				<td colspan="7" class="border-0">
            					<ul class="pagination justify-content-center">
            						<li class="page-item" data-ng-class="prevPageDisabled()">
            							<a class="page-link" href="" data-ng-click="prevPage()">Prev</a>
            						</li>
            						<li class="page-item" data-ng-repeat="n in range()" 
                                        data-ng-class="{active: n == currentPage}"
            				            data-ng-click="setPage(n)">
            							     <a class="page-link" href="">{{n+1}}</a>
            						</li>
            						<li class="page-item" data-ng-class="nextPageDisabled()">
            							<a class="page-link" href="" data-ng-click="nextPage()">Next</a>
            						</li>
            					</ul>
            				</td>
                            </tr>
            			</tfoot>
                    </div>
                </table>
            </div>

        </div>
        
        <div class="modal fade" id="viewModal">
             <div class="modal-dialog modal-lg">
                 <div class="modal-content">

                     <!-- Modal Header -->
                     <div class="modal-header">
                         <h4 class="modal-title">Technical Report</h4>
                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                     </div>

                     <!-- Modal body -->
                     <div class="modal-body">
                         <form method="get" id="ticketForm">

                             <!--customer section-->
                             <div id="customer_section">
                                 <div class="row">
                                     <div class="col-md-12 col-sm-12">
                                         <label for="ticNo" class="font-weight-bold col-md-3 col-sm-3">Ticket No </label>:
                                         <label id="ticNum">{{tno}}</label>
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="date">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Date Created </label>:
                                         {{date}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="title">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Product </label>:
                                         {{title}}
                                     </div>
                                 </div>
                                 <div data-ng-show="warran" class="row">
                                    <div class="col-md-12 col-sm-12">
                                         <label for="warranty" class="font-weight-bold col-md-3 col-sm-3">Warranty</label>:
                                         <!--                                         <img src="img/q_mark.png" title="Is your work or system is still in warranty?" style="max-width: 15px; max-height: 15px;">-->
                                         <span class="text-capitalize">{{warran}}</span>
                                     </div>
                                 </div>
                                  <div class="row" data-ng-show="cust_desc">
                                     <div class="col-md-12 col-sm-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Description</label>:
                                         {{cust_desc}}
                                         <!--<textarea value="{{cust_desc}}" data-ng-model="diagnosis" class="form-control w-100" rows="3" readonly></textarea>-->
                                     </div>
                                 </div>
                                 <div class="row">
                                     <div class="col-md-12 col-sm-12">
                                         <label for="namelbl" class="font-weight-bold col-md-3 col-sm-3">Client Name</label>:
                                         <span class="text-capitalize">{{CustName}}</span>
                                         <!--<input type="text" readonly class="form-control w-100" value="{{CustName}}">-->
                                     </div>
                                     <div data-ng-show="domainName!==''" class="col-md-12 col-sm-12">
                                         <label for="domainlbl" class="font-weight-bold col-md-3 col-sm-3">Domain Name</label>:
                                         {{domainName}}
                                         <!--<input type="text" class="form-control w-100" value="{{domainName}}" readonly />-->
                                     </div>
                                 </div>
                                 <div class="row"  data-ng-show="contactNum">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Contact </label>:
                                         {{contactNum}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="email">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Email </label>:
                                         {{email}}
                                     </div>
                                 </div>
                                 <div data-ng-show="jobType!==''" class="row">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Job Type </label>:
                                         {{jobType}}
                                     </div>
                                 </div>
                                 <hr>
                                 <div class="row" data-ng-show="sdate!==emptyDate">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Date Started</label>:
                                         {{sdate}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="edate!==emptyDate">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Date Solved </label>:
                                         {{edate}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="EmpName">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Attended By</label>:
                                         {{EmpName}}
                                     </div>
                                 </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         <div data-ng-hide="budgetTime==''">
                                            <label class="col-md-3 col-sm-3"><b>Budget Time</b></label>:
                                            <label>{{trunc(budgetTime)}} hrs {{trunc((budgetTime-trunc(budgetTime))*60)}} mins
                                         </div>
                                     </div>
                                 </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         <label class="col-md-3 col-sm-3"><b>Total Time Spent</b></label>:
                                         <label>{{trunc(totalTimeSpent)}} hrs {{trunc((totalTimeSpent-trunc(totalTimeSpent))*60)}} mins</label>
                                     </div>
                                 </div>
                             </div>
                             <hr>
                             <div class="row" data-ng-hide="online=='' && offline==''">
                                 <div class="col-md-12">
                                     <label for="source" class="font-weight-bold">Source Code: </label>
                                     <br />                                     
                                     <span data-ng-show="online"> Online: {{online}}</span>
                                     <span data-ng-show="offline"><br />Offline: {{offline}}</span>
                                 </div>
                             </div>
                             
                             
                             <div class="row" data-ng-hide="addDesc==''">
                                 <div class="col-md-12">
                                     <hr>
                                     <label class="font-weight-bold">Additional Description: </label>
                                     {{addDesc}}
                                     <br />
                                 </div>
                                 <hr>
                             </div>

                             
                             <!--lvl a-->
                             <label class="font-weight-bold">History: </label> <br>
                             <table class="table table-tasks table-sm table-striped table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Diagnosis</th>
                                        <th>Findings</th>
                                        <th>Cause</th>
                                        <th>Conclusion</th>
                                        <th>Spent</th>
                                        <th>Attended by</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr data-ng-repeat="log in logs">
                                        <td class="text-center">{{log.date}}</td>
                                        <td class="trunket">{{log.diagnosis}}</td>
                                        <td class="trunket">{{log.findings}}</td>
                                        <td class="trunket">{{log.cause}}</td>
                                        <td class="trunket">{{log.conclusion}}</td>
                                        <td>{{trunc(log.timeSpent)}}hr(s){{round((log.timeSpent-trunc(log.timeSpent))*60)}}mins</td>
                                        <td >{{log.attendedBy}}</td>
                                    </tr>
                                </tbody>
                            </table>
                         </form>
                     </div>

                     <!-- Modal footer -->
                     <div class="modal-footer">
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                     </div>
                 </div>
             </div>
         </div>
         </div>
    </div>
</div>



