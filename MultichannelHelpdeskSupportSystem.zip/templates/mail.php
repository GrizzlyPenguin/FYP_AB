<?php 
    // ini_set('display_errors', 1);
    // error_reporting(E_ALL);
    
    // $from = "mail.smdigital.com.my";
    // $to = "markgoh1997@gmail.com";
    
    // $subject = "PHP mail sending checking";
    // $message = "PHP mail works fine.";
    // $headers = "From:" . $from;
    
    // mail($to, $subject, $message, $headers);
    
    // echo "The email message was sucessfully sent.";
    // echo "Thank you";
    
    
// $to      = 'markgoh1997@gmail.com';
// $subject = 'the subject';
// $message = 'hello';
$headers = 'From: helpdesk@smdigital.com.my' . "\r\n" .
    'Reply-To: webmaster@example.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);

?>