<?php 
	session_start();
?>
<div data-ng-controller="putCtrl">
    <div class="table-tasks" data-ng-controller="getCtrl">
        <div ng-controller="sort" style="margin-top:50px; margin-left:20px">
            <div data-ng-controller="postCtrl">
                <span class="sr-only" data-ng-init="roleInit('<?php echo $_SESSION['Role']; ?>')"></span>
                <div class="tableTitle">
                    <div class="row">
                        <h3 data-ng-show="role">Every Pending Tasks </h3>
                        <h3 data-ng-hide="role">Task list</h3>

                        <div class="col p-0" data-ng-show="role">
                            <button data-toggle="modal" data-target="#myModal" class="btn btn-primary float-right">+ Ticket</button>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="personal" class="table table-sm table-striped table-bordered table-hover">
                        <thead>
                            <tr>
                                <th ng-click='sortColumn("ticketNo")' class="th-sm">#
                                </th>
                                <th ng-click='sortColumn("title")' class="th-sm">Product
                                </th>
                                <th ng-click='sortColumn("desc")' class="th-sm">Description
                                </th>
                                <th ng-click='sortColumn("name")' class="th-sm">Name
                                </th>
                                <th ng-click='sortColumn("date")' class="th-sm">Date Created
                                </th>
                                <th ng-click='sortColumn("date")' class="th-sm">Date Started
                                </th>
                                <th ng-click='sortColumn("status")' class="th-sm">Status
                                </th>
                            </tr>
                        </thead>
                        <div>
                            <span class="sr-only" data-ng-init="empInit('<?php echo $_SESSION['EmpID']; ?>')"></span>
                            <span class="sr-only" data-ng-init="custInit('<?php echo $_SESSION['CustID']; ?>')"></span>
                            <span class="sr-only" data-ng-init="tktLen('Pending')"></span>
                            <tbody>
                                <tr data-ng-repeat="ticket in tickets | orderBy:column:reverse|filter:searchText| filter:{status:'Pending'} | offset: currentPage*ticketsPerPage | limitTo: ticketsPerPage"  data-toggle="modal" data-target="#viewModal" data-ng-click="init(ticket); searchName(ticket.pid); getLog(ticket.ticketNo)">
                                    <td>{{ticket.ticketNo}}</td>
                                    <td>{{ticket.title}}</td>
                                    <td>{{ticket.desc}}</td>
                                    <td>{{ticket.Name}}</td>
                                    <td>{{ticket.date}}</td>
                                    <td>{{ticket.sdate}}</td>
                                    <td class="{{ticket.status}}"><b>{{ticket.status}}</b></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                				<td colspan="7" class="border-0">
                					<ul class="pagination justify-content-center">
                						<li class="page-item" data-ng-class="prevPageDisabled()">
                							<a class="page-link" href="" data-ng-click="prevPage()">Prev</a>
                						</li>
                						<li class="page-item" data-ng-repeat="n in range()" 
                                            data-ng-class="{active: n == currentPage}"
                				            data-ng-click="setPage(n)">
                							     <a class="page-link" href="">{{n+1}}</a>
                						</li>
                						<li class="page-item" data-ng-class="nextPageDisabled()">
                							<a class="page-link" href="" data-ng-click="nextPage()">Next</a>
                						</li>
                					</ul>
                				</td>
                                </tr>
                			</tfoot>
                        </div>
                    </table>
                </div>

                <div class="modal fade" id="editModal">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4 class="modal-title">Ticket Form</h4>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>

                            <!-- Modal body -->
                            <div class="modal-body">
                                <form method="get" id="ticketForm">

                                    <!--customer section-->
                                    <div id="customer_section">
                                        <div class="row">
                                            <div class="col-md-6 col-sm-12">
                                                <label for="ticNo" class="font-weight-bold">Ticket No: </label>
                                                <label id="ticNum">{{tno}}</label>
                                            </div>
                                            <div class="col-md-6 col-sm-12" style=" white-space: nowrap">
                                                <label for="warranty" class="font-weight-bold">Warranty:</label>
                                                <!--<img src="img/q_mark.png" title="Is your work or system is still in warranty?" style="max-width: 15px; max-height: 15px;">-->
                                                <input type="radio" name="warranty" value="yes" data-ng-hide="warran=='yes'" />
                                                <input type="radio" name="warranty" value="yes" data-ng-show="warran=='yes'" checked />
                                                <label>Yes</label>
                                                <span class="pl-3"></span>
                                                <input type="radio" name="warranty" value="no" data-ng-hide="warran=='no'" />
                                                <input type="radio" name="warranty" value="no" data-ng-show="warran=='no'" checked />
                                                <label>No</label>
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <label for="submitDate" class="font-weight-bold">Date Submit: </label>
                                                <label id="date">{{tDate}}</label>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 col-sm-12">
                                                <label for="namelbl" class="font-weight-bold">Client Name:</label>
                                                {{CustName}}
                                                <!--<input type="text" readonly class="form-control w-100" value="{{CustName}}">-->
                                            </div>
                                            <div class="col-md-6 col-sm-12">
                                                <label for="domainlbl" class="font-weight-bold">Domain Name:</label>
                                                {{domainName}}
                                                <!--<input type="text" class="form-control w-100" value="{{domainName}}" readonly />-->
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12 col-sm-12">
                                                <label class="font-weight-bold">Description:</label>
                                                {{cust_desc}}
                                                <!--<textarea value="{{cust_desc}}" data-ng-model="diagnosis" class="form-control w-100" rows="3" readonly></textarea>-->
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <label class="font-weight-bold">Job Type: </label>
                                                <select data-ng-model="jobType" class="col-md-6 browser-default custom-select">
                                                    <option value="log">Problem Log</option>
                                                    <option value="query">Query</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <br />
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label for="source" class="font-weight-bold">Source Code: </label>
                                            <br />
                                            <input type="text" data-ng-model="online" class="form-control w-100" placeholder="Online cloud" />
                                            <input type="text" data-ng-model="offline" class="form-control w-100" placeholder="Offline Source" />
                                        </div>

                                    </div>
                                    <br />


                                    <div class="row">
                                        <div class="col-md-12">
                                            <label class="font-weight-bold">Additional Description: </label>
                                            <br />
                                            <textarea value="{{addDesc}}" data-ng-model="addDesc" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="1" placeholder="Write description here..."></textarea>
                                        </div>
                                    </div>

                                    <hr>
                                    <!--lvl a-->
                                    
                                    <label class="font-weight-bold">Transferred By: {{transferredBy}}</label> <br>
                                    <label class="font-weight-bold">History: </label> <br>
                                    <table class="table table-sm table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Diagnosis</th>
                                                <th>Findings</th>
                                                <th>Cause</th>
                                                <th>Conclusion</th>
                                                <th>Attended by</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr data-ng-repeat="log in logs">
                                                <td>{{log.date}}</td>
                                                <td class="trunket">{{log.diagnosis}}</td>
                                                <td class="trunket">{{log.findings}}</td>
                                                <td class="trunket">{{log.cause}}</td>
                                                <td class="trunket">{{log.conclusion}}</td>
                                                <td >{{log.attendedBy}}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <!--
                                    <br>
                                    <label class="font-weight-bold" id="lastedit"> Last Edited by: </label> <br>
                                    <label id="lasteditname" style="font-style: normal; font-weight: normal">date_name_id</label>
                                    <p>or do it using list</p>
-->


                                    <div data-ng-model="historyLog">
                                        <p class="font-weight-bold">Level A:</p>
                                        <label class="font-weight-bold">Diagnosis:</label> <br>
                                        <textarea value="" data-ng-model="diagnosis" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Write diagnosis here..."></textarea>
                                        <br>
                                        <label class="font-weight-bold"> Findings:</label> <br>
                                        <textarea value="" data-ng-model="findings" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Write findings here..."></textarea>
                                        <br>
                                        <label class="font-weight-bold">Nature of Cause:</label> <br>
                                        <textarea value="" data-ng-model="cause" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Write something here..."></textarea>
                                        <br>
                                        <label class="font-weight-bold">Conclusion:</label> <br>
                                        <textarea value="" data-ng-model="conclusion" class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Write conclusion here..."></textarea>
                                        <br>
                                    </div>

                                    <div class="form-group">
                                        <label for="transfer">Transfer task to: </label>
                                        <select class="browser-default custom-select" id="status" data-ng-model="TicketTransfer">
                                            <option></option>
                                            <option class="text-capitalize" data-ng-repeat="emp in emps | filter: {id: '!'+EmpID}" value={{emp.id}}>{{emp.name}}</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label for="status">Status</label>
                                        <select class="browser-default custom-select" id="status" data-ng-model="TicketStatus" data-ng-init="TicketStatus='Pending'">
                                            <option value="Open">Open</option>
                                            <option value="Pending">Pending</option>
                                            <option value="Solved">Solved</option>
                                        </select>
                                    </div>
                                </form>
                            </div>

                            <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="submit" form="ticketForm" value="Submit" class="btn btn-primary" data-ng-click="postLog(addDesc, diagnosis, findings, conclusion, cause, EmpID, tno, TicketStatus, TicketTransfer, online, offline, jobType)" data-dismiss="modal">Submit</button>
                                <button type="reset" class="btn btn-default">Reset</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>
                    </div>
                </div>


                <!--viewModal-->
         <div class="modal fade" id="viewModal">
             <div class="modal-dialog modal-lg">
                 <div class="modal-content">

                     <!-- Modal Header -->
                     <div class="modal-header">
                         <h4 class="modal-title">Technical Report</h4>
                         <button type="button" class="close" data-dismiss="modal">&times;</button>
                     </div>

                     <!-- Modal body -->
                     <div class="modal-body">
                         <form method="get" id="ticketForm">

                             <!--customer section-->
                             <div id="customer_section">
                                 <div class="row">
                                     <div class="col-md-12 col-sm-12">
                                         <label for="ticNo" class="font-weight-bold col-md-3 col-sm-3">Ticket No </label>:
                                         <label id="ticNum">{{tno}}</label>
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="date">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Date Created </label>:
                                         {{date}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="title">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Product </label>:
                                         {{title}}
                                     </div>
                                 </div>
                                 <div data-ng-show="warran" class="row">
                                    <div class="col-md-12 col-sm-12">
                                         <label for="warranty" class="font-weight-bold col-md-3 col-sm-3">Warranty</label>:
                                         <!--                                         <img src="img/q_mark.png" title="Is your work or system is still in warranty?" style="max-width: 15px; max-height: 15px;">-->
                                         <span class="text-capitalize">{{warran}}</span>
                                     </div>
                                 </div>
                                  <div class="row" data-ng-show="cust_desc">
                                     <div class="col-md-12 col-sm-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Description</label>:
                                         {{cust_desc}}
                                         <!--<textarea value="{{cust_desc}}" data-ng-model="diagnosis" class="form-control w-100" rows="3" readonly></textarea>-->
                                     </div>
                                 </div>
                                 <div class="row">
                                     <div class="col-md-12 col-sm-12">
                                         <label for="namelbl" class="font-weight-bold col-md-3 col-sm-3">Client Name</label>:
                                         <span class="text-capitalize">{{CustName}}</span>
                                         <!--<input type="text" readonly class="form-control w-100" value="{{CustName}}">-->
                                     </div>
                                     <div data-ng-show="domainName!==''" class="col-md-12 col-sm-12">
                                         <label for="domainlbl" class="font-weight-bold col-md-3 col-sm-3">Domain Name</label>:
                                         {{domainName}}
                                         <!--<input type="text" class="form-control w-100" value="{{domainName}}" readonly />-->
                                     </div>
                                 </div>
                                 <div class="row"  data-ng-show="contactNum">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Contact </label>:
                                         {{contactNum}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="email">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Email </label>:
                                         {{email}}
                                     </div>
                                 </div>
                                 <div data-ng-show="jobType!==''" class="row">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Job Type </label>:
                                         {{jobType}}
                                     </div>
                                 </div>
                                 <hr>
                                 <div class="row" data-ng-show="sdate!==emptyDate">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Date Started</label>:
                                         {{sdate}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="edate!==emptyDate">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Date Solved </label>:
                                         {{edate}}
                                     </div>
                                 </div>
                                 <div class="row" data-ng-show="EmpName">
                                     <div class="col-md-12">
                                         <label class="font-weight-bold col-md-3 col-sm-3">Attended By</label>:
                                         {{EmpName}}
                                     </div>
                                 </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         <div data-ng-hide="budgetTime==''">
                                            <label class="col-md-3 col-sm-3"><b>Budget Time</b></label>:
                                            <label>{{trunc(budgetTime)}} hrs {{trunc((budgetTime-trunc(budgetTime))*60)}} mins
                                         </div>
                                     </div>
                                 </div>
                                 <div class="row">
                                     <div class="col-md-12">
                                         <label class="col-md-3 col-sm-3"><b>Total Time Spent</b></label>:
                                         <label>{{trunc(totalTimeSpent)}} hrs {{trunc((totalTimeSpent-trunc(totalTimeSpent))*60)}} mins</label>
                                     </div>
                                 </div>
                             </div>
                             <hr>
                             <div class="row" data-ng-hide="online=='' && offline==''">
                                 <div class="col-md-12">
                                     <label for="source" class="font-weight-bold">Source Code: </label>
                                     <br />                                     
                                     <span data-ng-show="online"> Online: {{online}}</span>
                                     <span data-ng-show="offline"><br />Offline: {{offline}}</span>
                                 </div>
                             </div>
                             
                             
                             <div class="row" data-ng-hide="addDesc==''">
                                 <div class="col-md-12">
                                     <hr>
                                     <label class="font-weight-bold">Additional Description: </label>
                                     {{addDesc}}
                                     <br />
                                 </div>
                                 <hr>
                             </div>
                             <!--lvl a-->
                             <label class="font-weight-bold">History: </label> <br>
                             <table class="table table-tasks table-sm table-striped table-hover table-responsive">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Diagnosis</th>
                                        <th>Findings</th>
                                        <th>Cause</th>
                                        <th>Conclusion</th>
                                        <th>Spent</th>
                                        <th>Attended by</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr data-ng-repeat="log in logs">
                                        <td class="text-center">{{log.date}}</td>
                                        <td class="trunket">{{log.diagnosis}}</td>
                                        <td class="trunket">{{log.findings}}</td>
                                        <td class="trunket">{{log.cause}}</td>
                                        <td class="trunket">{{log.conclusion}}</td>
                                        <td>{{trunc(log.timeSpent)}}hr(s){{round((log.timeSpent-trunc(log.timeSpent))*60)}}mins</td>
                                        <td >{{log.attendedBy}}</td>
                                    </tr>
                                </tbody>
                            </table>
                         </form>
                     </div>

                     <!-- Modal footer -->
                     <div class="modal-footer">
                         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                     </div>
                 </div>
             </div>
         </div>
            </div>
        </div>
    </div>
</div>