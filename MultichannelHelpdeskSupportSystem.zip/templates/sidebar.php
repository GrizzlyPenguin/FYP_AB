<?php
include('../server.php');
?>

<div data-ng-controller="postCtrl" style="margin-top:50px">
    <span class="sr-only" data-ng-init="roleInit('<?php echo ucfirst($_SESSION['Role']); ?>')"></span>
    <div class="col-md-12 col-sm-12 col-xs-12 p-0">
        <div class="sidebar" id="sidebar-wrapper">
            <div class="welcome">
                <h5><b class="text-danger">{{role}}</b></h5>
                <p>Welcome <a class="nav-link p-0 m-0" href="account_edit.php"><?php echo ucfirst($_SESSION['username']); ?></a></p>
               <p data-ng-hide="Logout == '0000-00-00 00:00:00'">Last Sign in: <?php echo ($_SESSION['Logout']); ?></p> 
            </div>

            <hr />
            <h5 data-ng-show="role"><b>Task Status</b></h5>
            <ul class="list-unstyled components">
                <li data-ng-show="role" class="sidebarhover" >
                    <a href="#Open">Open</a>
                </li>
                <li data-ng-show="role" class="sidebarhover" >
                    <a  href="#pendingAll">Pending</a>
                </li>
                <li data-ng-show="role" class="sidebarhover" >
                    <a href="#solvedAll">Solved</a>
                </li>
                <li data-ng-show="role" class="sidebarhover" >
                    <a href="#All">All</a>
                </li>
                <hr data-ng-show="role"/>
                <li class="active">
                    <h5 data-ng-show="role"><b>Personal</b></h5>
                    <h5 data-ng-hide="role"><b>My Ticket</b></h5>
                    <ul class="list-unstyled collapse show" id="Pending">
                        <li class="sidebarhover" >
                            <a href="#Pending">Pending</a>
                        </li>
                        <li class="sidebarhover" >
                            <a href="#Solved">Solved</a>
                        </li>
                        <li class="sidebarhover" >
                            <a href="#PersonalAll">All</a>
                        </li>
                    </ul>
                </li>

            </ul>
        </div>
    </div>
</div>
