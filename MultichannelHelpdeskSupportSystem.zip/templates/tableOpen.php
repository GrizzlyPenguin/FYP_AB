<?php 
	session_start();
?>

<div class="col-md-12 col-sm-12 col-xs-12 p-0">
    <div class="table-tasks" data-ng-controller="putCtrl">
        <div data-ng-controller="getCtrl">
        <div ng-controller="sort" style="margin-top:50px; margin-left:20px">
            <div data-ng-controller="postCtrl">
                <span class="sr-only" data-ng-init="roleInit('<?php echo $_SESSION['Role']; ?>')"></span>
                <div class="tableTitle">
                    <div class="row">
                        <h3 data-ng-show="role">Open Tasks</h3>
                        <h3 data-ng-hide="role">Open Tickets</h3>
                        
                        <div class="col p-0" data-ng-show="role">
                            <button data-toggle="modal" data-target="#myModal" class="btn btn-primary float-right">+ Ticket</button>
                        </div>
                    </div>
                </div>
                <div class="table-responsive">
                    <table id="open" class="table table-striped table-sm table-bordered table-hover">
                        <thead>
                            <tr class="text-center">
                                <th ng-click='sortColumn("ticketNo")' class="th-sm">#
                                </th>
                                <th ng-click='sortColumn("title")' class="th-sm">Product
                                </th>
                                <th ng-click='sortColumn("desc")' class="th-sm">Description
                                </th>
                                <th ng-click='sortColumn("pid")' class="th-sm">Customer
                                </th>
                                <th ng-click='sortColumn("date")' class="th-sm">Date Created
                                </th>
                                <th data-ng-show="role" class="th-sm">Action
                                </th>
                            </tr>
                        </thead>
                        <div>
                            <span class="sr-only" data-ng-init="empInit('<?php echo $_SESSION['EmpID']; ?>')"></span>
                            <span class="sr-only" data-ng-init="tktLen('Open')"></span>
                            <tbody>
                                <tr class="text-center" data-ng-repeat="ticket in tickets|orderBy:column:reverse|  filter:{status:'Open'} | offset: currentPage*ticketsPerPage | limitTo: ticketsPerPage"">
                                    <td>{{ticket.ticketNo}}</td>
                                    <td class="trunket">{{ticket.title}}</td>
                                    <td class="trunket">{{ticket.desc}}</td>
                                    <td >{{ticket.Name}}</td>
                                    <td>{{ticket.date}}</td>
                                    <td data-ng-show="role"><button class="btn btn-primary btn-sm" data-ng-click="putData(ticket.ticketNo, EmpID)">Accept</button></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                				<td colspan="7" class="border-0">
                					<ul class="pagination justify-content-center">
                						<li class="page-item" data-ng-class="prevPageDisabled()">
                							<a class="page-link" href="" data-ng-click="prevPage()">Prev</a>
                						</li>
                						<li class="page-item" data-ng-repeat="n in range()" 
                                            data-ng-class="{active: n == currentPage}"
                				            data-ng-click="setPage(n)">
                							     <a class="page-link" href="">{{n+1}}</a>
                						</li>
                						<li class="page-item" data-ng-class="nextPageDisabled()">
                							<a class="page-link" href="" data-ng-click="nextPage()">Next</a>
                						</li>
                					</ul>
                				</td>
                                </tr>
                			</tfoot>
                        </div>
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
