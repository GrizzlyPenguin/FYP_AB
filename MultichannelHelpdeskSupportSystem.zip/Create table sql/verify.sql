CREATE TABLE IF NOT EXISTS `VERIFY` (
`CustID` int(4) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
    `Email` varchar(30) NOT NULL,
    `Token` text NOT NULL,
    `ContactNumber` varchar(11) NOT NULL,
    `username` varchar(20) NOT NULL,
    `Password` varchar(50) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

ALTER TABLE `VERIFY`
 ADD PRIMARY KEY (`CustID`);

ALTER TABLE `VERIFY`
MODIFY `CustID` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1;